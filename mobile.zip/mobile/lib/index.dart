// Export pages
export '/pages/login/login_widget.dart' show LoginWidget;
export '/pages/cadastro/cadastro_widget.dart' show CadastroWidget;
export '/pages/main/main_widget.dart' show MainWidget;
export '/pages/relatar_problema/relatar_problema_widget.dart'
    show RelatarProblemaWidget;
export '/pages/chat/chat_widget.dart' show ChatWidget;
export '/pages/senha/senha_widget.dart' show SenhaWidget;
export '/pages/usuario/usuario_widget.dart' show UsuarioWidget;
export '/pages/usuario_copy/usuario_copy_widget.dart' show UsuarioCopyWidget;
